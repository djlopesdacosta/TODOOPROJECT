import xbmcaddon

MainBase = 'https://goo.gl/eSRKZr'
addon = xbmcaddon.Addon('plugin.video.casmart')